const button = document.getElementById("calculate-btn");
const input = document.getElementById("x_value");

function calculateFibonacci() {
  let x = document.getElementById("x_value").value;
  console.log(x);

  if (checkInput(x) !== "ok") {
    return console.log("the input is not a valid number");
  } else {
    if (x <= 1) {
      return x;
    } else {
      invisible(`result-space`);
      visible(`loader`);
      invisible(`alertMessage`);

      const server = `http://localhost:5050/fibonacci/${x}`;
      setTimeout(() => {
        fetch(server)
          .then(res => res.json())
          .then(function fetchResult(data) {
            invisible(`loader`);
            visible(`result-space`);
            document.getElementById("result-space").innerText = data.result;
            console.log(data.result);
          });
      }, 1000);
    }
  }
}

function checkInput(num) {
  const alertMessage = document.getElementById("alertMessage");
  if (isNaN(num)) {
    alertMessage.innerText = "Please insert a number";
    displayBlock(`alertMessage`);
    return console.log("The input was not a number");
  }
  if (num < 0) {
    alertMessage.innerText = "Please insert a positive number";
    displayBlock(`alertMessage`);
    return console.log("The input was a negative number");
  }
  if (num > 50) {
    alertMessage.innerText = "Please insert a positive number";
    displayBlock(`alertMessage`);
    return console.log("The maximum value is 50");
  } else {
    return "ok";
  }
}
function restart() {
  x = "";
  invisible(`alertMessage`);
  invisible(`loader`);
}
function visible(element) {
  let something = document.getElementById(`${element}`);
  something.classList.remove("unhide");
  something.classList.add("unhide");
}

function displayBlock(element) {
  let something = document.getElementById(`${element}`);
  something.classList.add("blockit");
}

function invisible(element) {
  let something = document.getElementById(`${element}`);
  something.classList.remove("unhide");
  something.classList.add("hide");
}

button.addEventListener("click", calculateFibonacci);
